import List from './List';

function App () {
    return (
        <>
            <div className='container'>
                <List />
            </div>
        </>
    );
}

export default App;